package swingmvclab;

import java.util.ArrayList;
import java.util.List;

/*
 * A hallgat�k adatait t�rol� oszt�ly.
 */
public class StudentData {

    /*
     * Ez a tagv�ltoz� t�rolja a hallgat�i adatokat.
     * NE M�DOS�TSD!
     */
    List<Student> students = new ArrayList<Student>();
    
}
